module.exports = {
	secretKey: '12345-67890-09876-54321',
	mongoURL: 'mongodb://localhost:27017/nucampsite',
	facebook: {
		clientId: '3387930651426822',
		clientSecret: '64ceb977b28f0c2b664a4da5a970ecd0',
	},
};
